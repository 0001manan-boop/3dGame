import { useCallback, useEffect, useState } from 'react';
import {
  Columns2,
  Eye,
  EyeOff,
  Maximize2,
  Pause,
  Play,
  Repeat,
  SkipBack,
  SkipForward,
  SunDim,
} from 'lucide-react';
import { WorldViewport } from './components/WorldViewport';
import { BIOME_PARTS, DEFAULT_CYCLE_SECONDS } from './data/biomes';

type LoopMode = 'biome' | 'all';

export default function App() {
  const [biomeIndex, setBiomeIndex] = useState<number>(0);
  const [stageIndex, setStageIndex] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [loopMode, setLoopMode] = useState<LoopMode>('biome');
  const [cycleSeconds, setCycleSeconds] = useState<number>(DEFAULT_CYCLE_SECONDS);
  const [secondsRemaining, setSecondsRemaining] = useState<number>(DEFAULT_CYCLE_SECONDS);
  const [backdropDim, setBackdropDim] = useState<number>(0.2);
  const [showSplitGuide, setShowSplitGuide] = useState<boolean>(false);
  const [isTheater, setIsTheater] = useState<boolean>(false);
  const [isCleanRecord, setIsCleanRecord] = useState<boolean>(false);

  const currentBiome = BIOME_PARTS[biomeIndex];
  const currentStage = currentBiome.stages[stageIndex] ?? currentBiome.stages[0];

  const advanceStage = useCallback(
    (direction: 1 | -1 = 1) => {
      setSecondsRemaining(cycleSeconds);

      if (loopMode === 'biome') {
        setStageIndex((prevStage) => {
          const total = BIOME_PARTS[biomeIndex].stages.length;
          return (prevStage + direction + total) % total;
        });
        return;
      }

      setStageIndex((prevStage) => {
        const len = BIOME_PARTS[biomeIndex].stages.length;
        const next = prevStage + direction;
        if (next >= 0 && next < len) {
          return next;
        }
        if (direction === 1) {
          setBiomeIndex((prevB) => (prevB + 1) % BIOME_PARTS.length);
          return 0;
        }
        const prevB = (biomeIndex - 1 + BIOME_PARTS.length) % BIOME_PARTS.length;
        setBiomeIndex(prevB);
        return BIOME_PARTS[prevB].stages.length - 1;
      });
    },
    [biomeIndex, cycleSeconds, loopMode]
  );

  // Continuous auto-style countdown until stopped
  useEffect(() => {
    if (!isPlaying) return;
    const timer = window.setInterval(() => {
      setSecondsRemaining((prev) => {
        if (prev <= 1) {
          advanceStage(1);
          return cycleSeconds;
        }
        return prev - 1;
      });
    }, 1000);
    return () => window.clearInterval(timer);
  }, [isPlaying, advanceStage, cycleSeconds]);

  const handleSelectBiome = (bIdx: number, targetStage = 0) => {
    setBiomeIndex(bIdx);
    setStageIndex(targetStage);
    setSecondsRemaining(cycleSeconds);
    setIsPlaying(true);
  };

  const handleSelectStage = (sIdx: number) => {
    setStageIndex(sIdx);
    setSecondsRemaining(cycleSeconds);
    setIsPlaying(true);
  };

  const handleChangeCycleInterval = (secs: number) => {
    setCycleSeconds(secs);
    setSecondsRemaining(secs);
  };

  const handleTogglePlay = useCallback(() => {
    setIsPlaying((prev) => !prev);
  }, []);

  const handleToggleCleanRecord = useCallback(() => {
    setIsCleanRecord((prev) => !prev);
  }, []);

  const handleEnterCleanTheater = useCallback(() => {
    setIsTheater((prev) => {
      const next = !prev;
      if (next) {
        setIsCleanRecord(true);
        if (document.documentElement.requestFullscreen) {
          document.documentElement.requestFullscreen().catch(() => {});
        }
      } else {
        setIsCleanRecord(false);
        if (document.fullscreenElement && document.exitFullscreen) {
          document.exitFullscreen().catch(() => {});
        }
      }
      return next;
    });
  }, []);

  // Keyboard shortcuts for fast OBS / Screen Recording control
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;
      if (e.code === 'Space') {
        e.preventDefault();
        handleTogglePlay();
      } else if (e.code === 'ArrowRight') {
        e.preventDefault();
        advanceStage(1);
      } else if (e.code === 'ArrowLeft') {
        e.preventDefault();
        advanceStage(-1);
      } else if (e.key === 'h' || e.key === 'H') {
        e.preventDefault();
        handleToggleCleanRecord();
      } else if (e.key === 'f' || e.key === 'F') {
        e.preventDefault();
        handleEnterCleanTheater();
      } else if (e.key === 'Escape' && isTheater) {
        setIsTheater(false);
        setIsCleanRecord(false);
        if (document.fullscreenElement && document.exitFullscreen) {
          document.exitFullscreen().catch(() => {});
        }
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [handleTogglePlay, advanceStage, handleToggleCleanRecord, handleEnterCleanTheater, isTheater]);

  return (
    <div className="min-h-screen bg-[#0A0B0E] text-[#F4F1EA]">
      {/* Clean 3-Zone Top Bar */}
      <header className="border-b border-[#1C1F28] bg-[#0A0B0E] sticky top-0 z-30">
        <div className="max-w-[1360px] mx-auto px-5 sm:px-8 py-4 flex items-center justify-between gap-8">
          <a
            href="#stage"
            className="font-display text-xl font-semibold tracking-tight text-[#F4F1EA] whitespace-nowrap shrink-0"
          >
            Optica Fauna
          </a>

          <nav
            aria-label="Primary sections"
            className="hidden md:flex items-center gap-7 text-sm font-medium text-[#A19E95]"
          >
            <a
              href="#stage"
              className="hover:text-[#F4F1EA] transition-colors whitespace-nowrap shrink-0"
            >
              16:9 World
            </a>
            <a
              href="#stages"
              className="hover:text-[#F4F1EA] transition-colors whitespace-nowrap shrink-0"
            >
              Camera Stages
            </a>
            <a
              href="#worlds"
              className="hover:text-[#F4F1EA] transition-colors whitespace-nowrap shrink-0"
            >
              10 Animal Biomes
            </a>
            <a
              href="#guide"
              className="hover:text-[#F4F1EA] transition-colors whitespace-nowrap shrink-0"
            >
              Recording Guide
            </a>
          </nav>

          <div className="shrink-0">
            <button
              type="button"
              onClick={handleEnterCleanTheater}
              className="px-4 py-2 rounded-lg bg-[#D97706] hover:bg-[#B45309] text-white text-xs font-semibold inline-flex items-center gap-2 transition-colors whitespace-nowrap shrink-0"
            >
              <Maximize2 className="w-3.5 h-3.5" />
              <span>16:9 Clean Record</span>
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-[1360px] mx-auto px-5 sm:px-8 py-8 space-y-12">
        {/* Dominant Focal Anchor: 16:9 Stylized 3D Living Nature World */}
        <section id="stage" aria-label="16:9 3D Nature Documentary Backdrop">
          <div className="mb-5 flex flex-col lg:flex-row lg:items-end justify-between gap-4">
            <div>
              <p className="text-xs text-[#A19E95] font-mono tabular-nums">
                World {String(currentBiome.partNumber).padStart(2, '0')} of 10
                <span className="mx-2" aria-hidden="true">·</span>
                Stage {currentStage.stageNumber} of {currentBiome.stages.length}
                <span className="mx-2" aria-hidden="true">·</span>
                {currentBiome.animalTopics}
                <span className="mx-2" aria-hidden="true">·</span>
                16:9 3D Cartoon World
              </p>
              <h1
                className="font-display text-2xl sm:text-3xl font-semibold text-[#F4F1EA] mt-1 tracking-tight"
                style={{ textWrap: 'balance' }}
              >
                {String(currentBiome.partNumber).padStart(2, '0')}. {currentBiome.name} —{' '}
                {currentStage.title}
              </h1>
            </div>

            <p className="text-sm text-[#B8B4AA] max-w-xl leading-relaxed">
              {currentStage.description}
            </p>
          </div>

          <WorldViewport
            biome={currentBiome}
            stage={currentStage}
            isPlaying={isPlaying}
            secondsRemaining={secondsRemaining}
            cycleSeconds={cycleSeconds}
            backdropDim={backdropDim}
            showSplitGuide={showSplitGuide}
            isTheater={isTheater}
            isCleanRecord={isCleanRecord}
            onTogglePlay={handleTogglePlay}
            onPrevStage={() => advanceStage(-1)}
            onNextStage={() => advanceStage(1)}
            onToggleTheater={handleEnterCleanTheater}
            onToggleCleanRecord={handleToggleCleanRecord}
          />

          {/* Documentary Recording Studio Toolbar */}
          <div className="mt-4 p-4 rounded-xl bg-[#12141A] border border-[#1E222D] flex flex-wrap items-center justify-between gap-4">
            {/* Playback Controls */}
            <div className="flex flex-wrap items-center gap-2.5">
              <button
                type="button"
                onClick={handleTogglePlay}
                className={`px-4 py-2 rounded-lg text-xs font-semibold inline-flex items-center gap-2 transition-colors whitespace-nowrap shrink-0 ${
                  isPlaying
                    ? 'bg-[#D97706] hover:bg-[#B45309] text-white'
                    : 'bg-[#F4F1EA] hover:bg-white text-[#0A0B0E]'
                }`}
              >
                {isPlaying ? (
                  <>
                    <Pause className="w-3.5 h-3.5" />
                    <span>Stop</span>
                  </>
                ) : (
                  <>
                    <Play className="w-3.5 h-3.5" />
                    <span>Play</span>
                  </>
                )}
              </button>

              <button
                type="button"
                onClick={() => advanceStage(-1)}
                className="px-3 py-2 rounded-lg bg-[#1A1D26] hover:bg-[#242834] text-[#F4F1EA] text-xs font-medium inline-flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0"
              >
                <SkipBack className="w-3.5 h-3.5" />
                <span>Prev</span>
              </button>

              <button
                type="button"
                onClick={() => advanceStage(1)}
                className="px-3 py-2 rounded-lg bg-[#1A1D26] hover:bg-[#242834] text-[#F4F1EA] text-xs font-medium inline-flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0"
              >
                <span>Next Style</span>
                <SkipForward className="w-3.5 h-3.5" />
              </button>

              {/* Loop Mode Selector */}
              <div
                className="inline-flex items-center p-1 rounded-lg bg-[#0A0B0E] border border-[#1E222D]"
                role="group"
                aria-label="Loop Mode"
              >
                <button
                  type="button"
                  onClick={() => setLoopMode('biome')}
                  className={`px-3 py-1.5 rounded-md text-xs font-medium inline-flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 ${
                    loopMode === 'biome'
                      ? 'bg-[#1E222D] text-[#F4F1EA]'
                      : 'text-[#8F8B82] hover:text-[#F4F1EA]'
                  }`}
                >
                  <Repeat className="w-3.5 h-3.5" />
                  <span>Loop Biome</span>
                </button>
                <button
                  type="button"
                  onClick={() => setLoopMode('all')}
                  className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                    loopMode === 'all'
                      ? 'bg-[#1E222D] text-[#F4F1EA]'
                      : 'text-[#8F8B82] hover:text-[#F4F1EA]'
                  }`}
                >
                  Tour All 10
                </button>
              </div>
            </div>

            {/* Documentary Safety & Timer Controls */}
            <div className="flex flex-wrap items-center gap-2.5">
              {/* Auto-Switch Interval Selector */}
              <div
                className="inline-flex items-center p-1 rounded-lg bg-[#0A0B0E] border border-[#1E222D]"
                role="group"
                aria-label="Auto-switch duration"
              >
                {[30, 45, 60].map((secs) => (
                  <button
                    key={secs}
                    type="button"
                    onClick={() => handleChangeCycleInterval(secs)}
                    className={`px-2.5 py-1.5 rounded-md text-xs font-mono tabular-nums transition-colors whitespace-nowrap shrink-0 ${
                      cycleSeconds === secs
                        ? 'bg-[#1E222D] text-[#F4B860]'
                        : 'text-[#8F8B82] hover:text-[#F4F1EA]'
                    }`}
                  >
                    {secs}s
                  </button>
                ))}
              </div>

              {/* Caption / Photo Contrast Dimmer */}
              <div
                className="inline-flex items-center gap-1 p-1 rounded-lg bg-[#0A0B0E] border border-[#1E222D]"
                role="group"
                aria-label="Caption contrast tint"
              >
                <span className="px-2 text-xs text-[#8F8B82] inline-flex items-center gap-1 whitespace-nowrap">
                  <SunDim className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Tint</span>
                </span>
                {[
                  { label: '0%', val: 0 },
                  { label: '20%', val: 0.2 },
                  { label: '35%', val: 0.35 },
                  { label: '50%', val: 0.5 },
                ].map((opt) => (
                  <button
                    key={opt.label}
                    type="button"
                    onClick={() => setBackdropDim(opt.val)}
                    className={`px-2 py-1.5 rounded-md text-xs font-mono tabular-nums transition-colors whitespace-nowrap shrink-0 ${
                      backdropDim === opt.val
                        ? 'bg-[#1E222D] text-[#F4F1EA]'
                        : 'text-[#8F8B82] hover:text-[#F4F1EA]'
                    }`}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>

              {/* Split Layout Safe-Zone Preview Toggle */}
              <button
                type="button"
                onClick={() => setShowSplitGuide((v) => !v)}
                className={`px-3 py-2 rounded-lg text-xs font-medium inline-flex items-center gap-1.5 border transition-colors whitespace-nowrap shrink-0 ${
                  showSplitGuide
                    ? 'bg-[#1E222D] border-[#343B4C] text-[#F4F1EA]'
                    : 'bg-transparent border-[#1E222D] text-[#A19E95] hover:text-[#F4F1EA]'
                }`}
              >
                <Columns2 className="w-3.5 h-3.5" />
                <span>Split Guide</span>
              </button>

              <button
                type="button"
                onClick={handleToggleCleanRecord}
                className={`px-3 py-2 rounded-lg text-xs font-medium inline-flex items-center gap-1.5 border transition-colors whitespace-nowrap shrink-0 ${
                  isCleanRecord
                    ? 'bg-[#D97706] border-[#D97706] text-white'
                    : 'bg-transparent border-[#1E222D] text-[#A19E95] hover:text-[#F4F1EA]'
                }`}
              >
                {isCleanRecord ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                <span>{isCleanRecord ? 'Show HUD (H)' : 'Hide HUD (H)'}</span>
              </button>
            </div>
          </div>
        </section>

        {/* Active Biome's 4 Camera & Lighting Stages */}
        <section id="stages" className="pt-2 border-t border-[#1C1F28]">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3 mb-5">
            <div>
              <p className="text-xs text-[#A19E95]">
                Active Biome Camera Styles · Auto-Cycles Every {cycleSeconds}s Until Stopped
              </p>
              <h2 className="font-display text-xl sm:text-2xl font-semibold text-[#F4F1EA] mt-1">
                {currentBiome.name} — 4 Camera & Lighting Stages
              </h2>
            </div>
            <p className="text-xs text-[#A19E95] max-w-md">{currentBiome.subtitle}</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {currentBiome.stages.map((st, idx) => {
              const isActive = idx === stageIndex;
              return (
                <button
                  key={st.id}
                  type="button"
                  onClick={() => handleSelectStage(idx)}
                  className={`text-left p-5 rounded-xl border transition-colors flex flex-col justify-between gap-3 ${
                    isActive
                      ? 'bg-[#181B24] border-[#D97706]'
                      : 'bg-[#12141A] border-[#1E222D] hover:border-[#343B4C]'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between gap-2 text-xs font-mono tabular-nums text-[#A19E95]">
                      <span>Stage {String(st.stageNumber).padStart(2, '0')}</span>
                      <span className={isActive ? 'text-[#F4B860]' : 'text-[#747068]'}>
                        {isActive
                          ? isPlaying
                            ? `${secondsRemaining}s left`
                            : 'Selected'
                          : `${cycleSeconds}s cycle`}
                      </span>
                    </div>
                    <h3 className="mt-2 font-display text-base font-semibold text-[#F4F1EA]">
                      {st.title}
                    </h3>
                    <p className="mt-1 text-xs text-[#D97706] font-medium">
                      Sun {st.sunElevation}° · Speed {st.cameraSpeed.toFixed(1)}×
                    </p>
                  </div>
                  <p className="text-xs text-[#A19E95] leading-relaxed">{st.description}</p>
                </button>
              );
            })}
          </div>
        </section>

        {/* 10 Animal-Matched 3D Biomes */}
        <section id="worlds" className="pt-2 border-t border-[#1C1F28]">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3 mb-6">
            <div>
              <p className="text-xs text-[#A19E95]">
                10 Stylized 3D Worlds · Matched by Animal Documentary Topic
              </p>
              <h2 className="font-display text-xl sm:text-2xl font-semibold text-[#F4F1EA] mt-1">
                Choose Your Documentary Environment
              </h2>
            </div>
            <p className="text-xs text-[#A19E95] max-w-md">
              Pick the biome matching your episode (e.g. Emerald Meadow for Dog breeds, Coral Lagoon for Whales/Sharks) and record endlessly until stopped.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
            {BIOME_PARTS.map((b, bIdx) => {
              const isSelected = bIdx === biomeIndex;
              return (
                <div
                  key={b.id}
                  className={`rounded-xl border p-4 transition-colors flex flex-col justify-between gap-3 ${
                    isSelected
                      ? 'bg-[#171A22] border-[#D97706]'
                      : 'bg-[#12141A] border-[#1E222D] hover:border-[#303646]'
                  }`}
                >
                  <button
                    type="button"
                    onClick={() => handleSelectBiome(bIdx, 0)}
                    className="text-left w-full group space-y-3"
                  >
                    {/* Biome Sky/Terrain Preview Gradient Card (16:9) */}
                    <div
                      className="w-full aspect-video rounded-md border border-[#1E222D] relative overflow-hidden flex items-end p-2"
                      style={{
                        background: `linear-gradient(180deg, ${b.palette.skyTop} 0%, ${b.palette.skyHorizon} 58%, ${b.palette.terrainHigh} 62%, ${b.palette.terrainLow} 100%)`,
                      }}
                    >
                      <div
                        className="w-3 h-3 rounded-full shadow-sm"
                        style={{ backgroundColor: b.palette.sun }}
                      />
                    </div>

                    <div>
                      <div className="flex items-center justify-between text-xs font-mono tabular-nums text-[#8F8B82]">
                        <span>World {String(b.partNumber).padStart(2, '0')}</span>
                        <span className={isSelected ? 'text-[#F4B860]' : ''}>
                          {isSelected ? (isPlaying ? 'Playing' : 'Stopped') : '4 Stages'}
                        </span>
                      </div>
                      <h3 className="mt-1 font-display text-base font-semibold text-[#F4F1EA] group-hover:text-[#F4B860] transition-colors">
                        {b.name}
                      </h3>
                      <p className="mt-0.5 text-xs text-[#D97706] font-medium truncate">
                        {b.animalTopics}
                      </p>
                    </div>
                  </button>

                  <div className="pt-2 border-t border-[#1E222D] grid grid-cols-4 gap-1">
                    {b.stages.map((st, sIdx) => {
                      const activeStage = isSelected && sIdx === stageIndex;
                      return (
                        <button
                          key={st.id}
                          type="button"
                          onClick={() => handleSelectBiome(bIdx, sIdx)}
                          title={`${b.name} — Stage ${st.stageNumber}: ${st.title}`}
                          className={`py-1 rounded text-[11px] font-mono tabular-nums transition-colors ${
                            activeStage
                              ? 'bg-[#D97706] text-white font-semibold'
                              : 'bg-[#0A0B0E] text-[#9A968D] hover:text-[#F4F1EA] hover:bg-[#1E222D]'
                          }`}
                        >
                          S{st.stageNumber}
                        </button>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        </section>

        {/* Practical OBS / Video Editing Workflow Guide */}
        <section id="guide" className="pt-8 pb-6 border-t border-[#1C1F28]">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <h3 className="font-display text-lg font-semibold text-[#F4F1EA]">
                01. Match Biome to Your Episode
              </h3>
              <p className="mt-2 text-sm text-[#A19E95] leading-relaxed">
                Select a world tailored to your script—such as Emerald Meadow for Dog breeds, Golden Savanna for Lions & Elephants, or Coral Lagoon for Whales & Sharks. Use Loop Biome to stay inside one cohesive world all episode.
              </p>
            </div>
            <div>
              <h3 className="font-display text-lg font-semibold text-[#F4F1EA]">
                02. Protect Caption & Photo Contrast
              </h3>
              <p className="mt-2 text-sm text-[#A19E95] leading-relaxed">
                Toggle Split Guide to preview where your animal image (left) and captions (right) sit, then set Tint to 20% or 35% so white captions and cutout photos remain crisp against sunny skies.
              </p>
            </div>
            <div>
              <h3 className="font-display text-lg font-semibold text-[#F4F1EA]">
                03. Clean 16:9 Screen Recording
              </h3>
              <p className="mt-2 text-sm text-[#A19E95] leading-relaxed">
                Click 16:9 Clean Record (or press F) to fill your screen in strict 16:9 with all controls hidden. Press H anytime to toggle HUD visibility, Space to pause/play, and Esc to exit fullscreen.
              </p>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}
