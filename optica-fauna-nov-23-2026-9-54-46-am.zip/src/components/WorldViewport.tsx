import React, { useEffect, useRef, useState } from 'react';
import {
  Eye,
  EyeOff,
  Maximize2,
  Minimize2,
  Pause,
  Play,
  SkipBack,
  SkipForward,
} from 'lucide-react';
import { BiomeDefinition, BiomeStage } from '../data/biomes';
import { NatureWorld3D } from '../engine/world3d';

interface WorldViewportProps {
  biome: BiomeDefinition;
  stage: BiomeStage;
  isPlaying: boolean;
  secondsRemaining: number;
  cycleSeconds: number;
  backdropDim: number;
  showSplitGuide: boolean;
  isTheater: boolean;
  isCleanRecord: boolean;
  onTogglePlay: () => void;
  onPrevStage: () => void;
  onNextStage: () => void;
  onToggleTheater: () => void;
  onToggleCleanRecord: () => void;
}

export const WorldViewport: React.FC<WorldViewportProps> = ({
  biome,
  stage,
  isPlaying,
  secondsRemaining,
  cycleSeconds,
  backdropDim,
  showSplitGuide,
  isTheater,
  isCleanRecord,
  onTogglePlay,
  onPrevStage,
  onNextStage,
  onToggleTheater,
  onToggleCleanRecord,
}) => {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const worldRef = useRef<NatureWorld3D | null>(null);
  const [contextLost, setContextLost] = useState(false);

  const initialBiomeRef = useRef(biome);
  const initialStageRef = useRef(stage);

  // Initialize Three.js world once in isolated ref container
  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const world = new NatureWorld3D(
      container,
      initialBiomeRef.current,
      initialStageRef.current,
      {
        onContextLost: () => setContextLost(true),
        onContextRestored: () => setContextLost(false),
      }
    );
    worldRef.current = world;

    return () => {
      world.dispose();
      worldRef.current = null;
    };
  }, []);

  // Push biome/stage updates smoothly without recreating WebGL context
  useEffect(() => {
    worldRef.current?.setSceneTarget(biome, stage);
  }, [biome, stage]);

  // Push play/stop state
  useEffect(() => {
    worldRef.current?.setPlaying(isPlaying);
  }, [isPlaying]);

  // Trigger resize when toggling theater mode
  useEffect(() => {
    const id = window.setTimeout(() => {
      worldRef.current?.handleResize();
    }, 30);
    return () => window.clearTimeout(id);
  }, [isTheater]);

  const progressPercent = ((cycleSeconds - secondsRemaining) / cycleSeconds) * 100;

  const viewportFrame = (
    <div
      className={
        isTheater
          ? 'theater-16-9-frame relative overflow-hidden bg-[#0B0E14] border border-[#1E2430] shadow-2xl'
          : 'relative w-full aspect-video overflow-hidden rounded-xl bg-[#0B0E14] border border-[#1E222D] shadow-2xl'
      }
    >
      {/* Isolated WebGL mount container */}
      <div ref={mountRef} className="w-full h-full" />

      {/* Documentary Backdrop Contrast Tint (for bright sky legibility behind photos/captions) */}
      {backdropDim > 0 && (
        <div
          className="absolute inset-0 pointer-events-none transition-opacity duration-300"
          style={{
            background: `linear-gradient(180deg, rgba(8,10,15,${(backdropDim * 0.85).toFixed(
              2
            )}) 0%, rgba(8,10,15,${backdropDim.toFixed(2)}) 100%)`,
          }}
        />
      )}

      {/* Optional Split-Screen Composition Guide (Left: Animal Photo | Right: Captions) */}
      {showSplitGuide && !isCleanRecord && (
        <div className="absolute inset-0 pointer-events-none p-8 grid grid-cols-2 gap-8 z-10">
          <div className="rounded-xl border border-dashed border-white/45 bg-black/25 flex flex-col items-center justify-center text-center p-4">
            <span className="text-xs font-mono uppercase tracking-wider text-white/85">
              Left Safe Zone
            </span>
            <span className="mt-1 text-sm font-semibold text-white">
              Animal / Dog Image Overlay
            </span>
          </div>
          <div className="rounded-xl border border-dashed border-white/45 bg-black/25 flex flex-col items-center justify-center text-center p-4">
            <span className="text-xs font-mono uppercase tracking-wider text-white/85">
              Right Safe Zone
            </span>
            <span className="mt-1 text-sm font-semibold text-white">
              Documentary Captions & Narration
            </span>
          </div>
        </div>
      )}

      {/* WebGL Context Lost Safe Fallback */}
      {contextLost && (
        <div className="absolute inset-0 bg-[#0B0E14] flex items-center justify-center p-6 text-center z-20">
          <p className="text-sm text-[#E5E0D5]">
            3D graphics context paused — restoring scene automatically.
          </p>
        </div>
      )}

      {/* Clean Record Mode tiny hover-escape button ONLY in non-theater or bottom-right */}
      {isCleanRecord && (
        <button
          type="button"
          onClick={onToggleCleanRecord}
          className="absolute top-3 right-3 z-20 px-3 py-1.5 rounded-md bg-black/45 hover:bg-black/80 text-white/75 hover:text-white text-[11px] font-medium opacity-0 hover:opacity-100 focus-visible:opacity-100 transition-opacity"
          title="Show HUD Controls (H)"
        >
          Show Controls (H)
        </button>
      )}

      {/* Collapsible Bottom Control Scrim (No backdrop-blur over WebGL) */}
      {!isCleanRecord && (
        <div className="absolute inset-x-0 bottom-0 z-20 bg-gradient-to-t from-[#080A0F]/92 via-[#080A0F]/65 to-transparent pt-10 pb-4 px-5">
          <div className="w-full h-1 bg-white/15 rounded-full overflow-hidden mb-3">
            <div
              className="h-full bg-[#E08E26] transition-[width] duration-200 ease-linear"
              style={{ width: `${Math.min(100, Math.max(0, progressPercent))}%` }}
            />
          </div>

          <div className="flex flex-wrap items-center justify-between gap-4">
            <div className="min-w-0">
              <div className="flex items-center gap-2 text-xs text-[#D1CCC0] font-mono tabular-nums">
                <span>World {String(biome.partNumber).padStart(2, '0')} of 10</span>
                <span aria-hidden="true">·</span>
                <span>Stage {stage.stageNumber} of 4</span>
                <span aria-hidden="true">·</span>
                <span>16:9 3D Backdrop</span>
                <span aria-hidden="true">·</span>
                <span className="text-[#F4B860]">
                  {isPlaying ? `Next style in ${secondsRemaining}s` : 'Stopped'}
                </span>
              </div>
              <div className="mt-1 flex items-baseline gap-3">
                <h2 className="font-display text-lg sm:text-xl font-semibold text-[#F4F1EA] truncate">
                  {biome.name} — {stage.title}
                </h2>
                <span className="hidden md:inline text-xs text-[#B6B1A7] truncate">
                  {biome.animalTopics}
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={onPrevStage}
                className="h-9 w-9 inline-flex items-center justify-center rounded-lg bg-[#1A1E29]/90 hover:bg-[#272D3D] text-[#F4F1EA] transition-colors"
                title="Previous Stage"
                aria-label="Previous Stage"
              >
                <SkipBack className="w-4 h-4" />
              </button>

              <button
                type="button"
                onClick={onTogglePlay}
                className={`h-9 px-4 inline-flex items-center gap-2 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                  isPlaying
                    ? 'bg-[#D97706] hover:bg-[#B45309] text-white'
                    : 'bg-[#F4F1EA] hover:bg-white text-[#0A0B0E]'
                }`}
              >
                {isPlaying ? (
                  <>
                    <Pause className="w-3.5 h-3.5" />
                    <span>Stop</span>
                  </>
                ) : (
                  <>
                    <Play className="w-3.5 h-3.5" />
                    <span>Play</span>
                  </>
                )}
              </button>

              <button
                type="button"
                onClick={onNextStage}
                className="h-9 w-9 inline-flex items-center justify-center rounded-lg bg-[#1A1E29]/90 hover:bg-[#272D3D] text-[#F4F1EA] transition-colors"
                title="Next Style Now"
                aria-label="Next Style Now"
              >
                <SkipForward className="w-4 h-4" />
              </button>

              <button
                type="button"
                onClick={onToggleCleanRecord}
                className="h-9 px-3 inline-flex items-center gap-1.5 rounded-lg bg-[#1A1E29]/90 hover:bg-[#272D3D] text-[#F4F1EA] text-xs font-medium transition-colors whitespace-nowrap shrink-0"
                title="Hide UI for Clean Screen Recording (H)"
              >
                {isCleanRecord ? (
                  <Eye className="w-3.5 h-3.5" />
                ) : (
                  <EyeOff className="w-3.5 h-3.5" />
                )}
                <span className="hidden sm:inline">Clean Record (H)</span>
              </button>

              <button
                type="button"
                onClick={onToggleTheater}
                className="h-9 px-3 inline-flex items-center gap-1.5 rounded-lg bg-[#1A1E29]/90 hover:bg-[#272D3D] text-[#F4F1EA] text-xs font-medium transition-colors whitespace-nowrap shrink-0"
                title={isTheater ? 'Exit 16:9 Fullscreen' : '16:9 Fullscreen Record'}
              >
                {isTheater ? (
                  <>
                    <Minimize2 className="w-3.5 h-3.5" />
                    <span>Exit 16:9</span>
                  </>
                ) : (
                  <>
                    <Maximize2 className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">16:9 Fullscreen</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );

  if (isTheater) {
    return (
      <div
        className="fixed inset-0 z-50 bg-black flex items-center justify-center"
        role="dialog"
        aria-modal="true"
        aria-label="16:9 Clean Recording Theater"
      >
        {viewportFrame}
      </div>
    );
  }

  return viewportFrame;
};
