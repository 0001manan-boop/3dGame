export type BiomeId =
  | 'emerald_meadow'
  | 'misty_pine_valley'
  | 'golden_savanna'
  | 'arctic_peaks'
  | 'coral_lagoon'
  | 'autumn_maple'
  | 'tropical_waterfall'
  | 'red_rock_canyon'
  | 'twilight_fireflies'
  | 'alpine_clouds';

export type TreeStyle = 'broadleaf' | 'pine' | 'acacia' | 'snow_pine' | 'coral' | 'palm' | 'cactus';
export type WildlifeType = 'birds' | 'fish' | 'butterflies';
export type ParticleType = 'pollen' | 'mist' | 'dust' | 'snow' | 'bubbles' | 'leaves' | 'fireflies';
export type CameraChoreography = 'glide_forward' | 'low_parallax' | 'panorama_orbit' | 'tranquil_drift';

export interface BiomeStage {
  id: string;
  stageNumber: number;
  title: string;
  choreography: CameraChoreography;
  description: string;
  sunElevation: number; // degrees above horizon
  cameraSpeed: number;
  ambientBoost: number;
}

export interface BiomeDefinition {
  id: BiomeId;
  partNumber: number;
  name: string;
  animalTopics: string;
  subtitle: string;
  treeStyle: TreeStyle;
  wildlife: WildlifeType;
  particles: ParticleType;
  isUnderwater?: boolean;
  palette: {
    skyTop: string;
    skyHorizon: string;
    fog: string;
    sun: string;
    terrainLow: string;
    terrainHigh: string;
    water: string;
    road: string;
    foliageA: string;
    foliageB: string;
    trunk: string;
    rock: string;
    particle: string;
    accent: string;
  };
  terrainAmplitude: number;
  waterLevel: number;
  fogDensity: number;
  stages: BiomeStage[];
}

export const DEFAULT_CYCLE_SECONDS = 30;

function createBiomeStages(biomeId: string, baseSpeed = 1): BiomeStage[] {
  return [
    {
      id: `${biomeId}-s1`,
      stageNumber: 1,
      title: 'Jungle Road Cruise',
      choreography: 'glide_forward',
      description: 'Smooth forward drive down a winding scenic road flanked by dense trees, bushes, and roadside posts.',
      sunElevation: 24,
      cameraSpeed: 1.0 * baseSpeed,
      ambientBoost: 1.0,
    },
    {
      id: `${biomeId}-s2`,
      stageNumber: 2,
      title: 'Low Road-Skim Parallax',
      choreography: 'low_parallax',
      description: 'Low-angle road glide passing lush shrubs and lanterns—ideal for keeping captions and animal photos sharp.',
      sunElevation: 16,
      cameraSpeed: 0.9 * baseSpeed,
      ambientBoost: 0.96,
    },
    {
      id: `${biomeId}-s3`,
      stageNumber: 3,
      title: 'Canopy Road Overlook',
      choreography: 'panorama_orbit',
      description: 'Elevated camera floating above the winding jungle highway with sweeping views of hills and wildlife.',
      sunElevation: 11,
      cameraSpeed: 0.75 * baseSpeed,
      ambientBoost: 1.08,
    },
    {
      id: `${biomeId}-s4`,
      stageNumber: 4,
      title: 'Golden Horizon Drive',
      choreography: 'tranquil_drift',
      description: 'Calm, rhythmic drive into warm horizon light with gentle particle drift for documentary narration.',
      sunElevation: 32,
      cameraSpeed: 0.68 * baseSpeed,
      ambientBoost: 1.02,
    },
  ];
}

export const BIOME_PARTS: BiomeDefinition[] = [
  {
    id: 'emerald_meadow',
    partNumber: 1,
    name: 'Emerald Meadow',
    animalTopics: 'Dogs · Horses · Farm Animals',
    subtitle: 'Sunlit rolling hills, wildflowers & gliding swallows',
    treeStyle: 'broadleaf',
    wildlife: 'birds',
    particles: 'pollen',
    palette: {
      skyTop: '#2E77B8',
      skyHorizon: '#BEE3F8',
      fog: '#B8DCF2',
      sun: '#FFF3C4',
      terrainLow: '#4F9A58',
      terrainHigh: '#78BC61',
      water: '#38A3C7',
      road: '#4A4E59',
      foliageA: '#3D8C48',
      foliageB: '#66B252',
      trunk: '#6E4B35',
      rock: '#7B848E',
      particle: '#FFF7D6',
      accent: '#4F9A58',
    },
    terrainAmplitude: 4.5,
    waterLevel: -1.4,
    fogDensity: 0.0085,
    stages: createBiomeStages('emerald_meadow', 1.0),
  },
  {
    id: 'misty_pine_valley',
    partNumber: 2,
    name: 'Misty Pine Valley',
    animalTopics: 'Wolves · Bears · Foxes',
    subtitle: 'Layered evergreen ridges & cool morning mist',
    treeStyle: 'pine',
    wildlife: 'birds',
    particles: 'mist',
    palette: {
      skyTop: '#253D52',
      skyHorizon: '#94B0C2',
      fog: '#8AA7BA',
      sun: '#FCE9C8',
      terrainLow: '#2E4F3E',
      terrainHigh: '#466D52',
      water: '#36687A',
      road: '#3D444E',
      foliageA: '#234C3A',
      foliageB: '#33674B',
      trunk: '#4D3629',
      rock: '#5F6B75',
      particle: '#E2EDF2',
      accent: '#33674B',
    },
    terrainAmplitude: 6.4,
    waterLevel: -1.8,
    fogDensity: 0.0115,
    stages: createBiomeStages('misty_pine_valley', 0.9),
  },
  {
    id: 'golden_savanna',
    partNumber: 3,
    name: 'Golden Savanna',
    animalTopics: 'Lions · Elephants · Giraffes',
    subtitle: 'Warm amber plains, flat-top acacias & sunset glow',
    treeStyle: 'acacia',
    wildlife: 'birds',
    particles: 'dust',
    palette: {
      skyTop: '#5A4166',
      skyHorizon: '#F4A261',
      fog: '#E7A36B',
      sun: '#FFE08A',
      terrainLow: '#B87A3D',
      terrainHigh: '#D49A4A',
      water: '#4E828A',
      road: '#8A603B',
      foliageA: '#5D7034',
      foliageB: '#7F8E3D',
      trunk: '#5B3E2B',
      rock: '#8C624A',
      particle: '#FFE4A8',
      accent: '#E08E26',
    },
    terrainAmplitude: 3.4,
    waterLevel: -1.6,
    fogDensity: 0.009,
    stages: createBiomeStages('golden_savanna', 1.05),
  },
  {
    id: 'arctic_peaks',
    partNumber: 4,
    name: 'Arctic Snow Peaks',
    animalTopics: 'Huskies · Polar Bears · Penguins',
    subtitle: 'Frost-tipped pines, alpine ridges & drifting snow',
    treeStyle: 'snow_pine',
    wildlife: 'birds',
    particles: 'snow',
    palette: {
      skyTop: '#264873',
      skyHorizon: '#CFE4F5',
      fog: '#C3DDF2',
      sun: '#FFFFFF',
      terrainLow: '#BFD6E8',
      terrainHigh: '#EDF6FC',
      water: '#4B89B3',
      road: '#627282',
      foliageA: '#3C6470',
      foliageB: '#DCEEF7',
      trunk: '#4E4440',
      rock: '#6E7F91',
      particle: '#FFFFFF',
      accent: '#60A5FA',
    },
    terrainAmplitude: 7.2,
    waterLevel: -1.7,
    fogDensity: 0.0095,
    stages: createBiomeStages('arctic_peaks', 0.85),
  },
  {
    id: 'coral_lagoon',
    partNumber: 5,
    name: 'Coral Lagoon',
    animalTopics: 'Whales · Sharks · Dolphins',
    subtitle: 'Stylized underwater reef, rising bubbles & fish schools',
    treeStyle: 'coral',
    wildlife: 'fish',
    particles: 'bubbles',
    isUnderwater: true,
    palette: {
      skyTop: '#0B3E5E',
      skyHorizon: '#18849E',
      fog: '#126B87',
      sun: '#80F2FF',
      terrainLow: '#1C6E7D',
      terrainHigh: '#3D999B',
      water: '#0F4D6B',
      road: '#2B7D8C',
      foliageA: '#F9735B',
      foliageB: '#EC4899',
      trunk: '#F59E0B',
      rock: '#2E5B6B',
      particle: '#BDF4FF',
      accent: '#22D3EE',
    },
    terrainAmplitude: 4.8,
    waterLevel: -8.0,
    fogDensity: 0.013,
    stages: createBiomeStages('coral_lagoon', 0.8),
  },
  {
    id: 'autumn_maple',
    partNumber: 6,
    name: 'Autumn Maple Ridge',
    animalTopics: 'Deer · Squirrels · Owls',
    subtitle: 'Amber & crimson canopies with drifting maple leaves',
    treeStyle: 'broadleaf',
    wildlife: 'butterflies',
    particles: 'leaves',
    palette: {
      skyTop: '#4A5D7A',
      skyHorizon: '#F2C08D',
      fog: '#DFB68E',
      sun: '#FFE6B0',
      terrainLow: '#8C6239',
      terrainHigh: '#B87E40',
      water: '#4B7888',
      road: '#5C4B3B',
      foliageA: '#C84B31',
      foliageB: '#E08E26',
      trunk: '#523A28',
      rock: '#786F68',
      particle: '#EE6C3B',
      accent: '#D97706',
    },
    terrainAmplitude: 5.2,
    waterLevel: -1.5,
    fogDensity: 0.009,
    stages: createBiomeStages('autumn_maple', 0.9),
  },
  {
    id: 'tropical_waterfall',
    partNumber: 7,
    name: 'Tropical Canopy',
    animalTopics: 'Parrots · Monkeys · Frogs',
    subtitle: 'Lush palms, emerald pools & fluttering butterflies',
    treeStyle: 'palm',
    wildlife: 'butterflies',
    particles: 'pollen',
    palette: {
      skyTop: '#1B6B73',
      skyHorizon: '#9CE3C8',
      fog: '#8BD9C0',
      sun: '#FFF8CE',
      terrainLow: '#1F7A52',
      terrainHigh: '#3FA664',
      water: '#22B8B8',
      road: '#5A4F42',
      foliageA: '#1E824C',
      foliageB: '#52BE64',
      trunk: '#755339',
      rock: '#5E6E6B',
      particle: '#C4FFE0',
      accent: '#10B981',
    },
    terrainAmplitude: 5.6,
    waterLevel: -1.1,
    fogDensity: 0.0095,
    stages: createBiomeStages('tropical_waterfall', 0.95),
  },
  {
    id: 'red_rock_canyon',
    partNumber: 8,
    name: 'Red Rock Canyon',
    animalTopics: 'Camels · Desert Foxes · Reptiles',
    subtitle: 'Terracotta desert dunes, cacti & golden dust',
    treeStyle: 'cactus',
    wildlife: 'birds',
    particles: 'dust',
    palette: {
      skyTop: '#3E4875',
      skyHorizon: '#F29568',
      fog: '#E3936B',
      sun: '#FFD599',
      terrainLow: '#B85437',
      terrainHigh: '#D97848',
      water: '#4E7D8C',
      road: '#8E4935',
      foliageA: '#4D8B55',
      foliageB: '#66A864',
      trunk: '#3E7344',
      rock: '#9E4632',
      particle: '#FFDDB3',
      accent: '#EA580C',
    },
    terrainAmplitude: 6.2,
    waterLevel: -4.5,
    fogDensity: 0.0085,
    stages: createBiomeStages('red_rock_canyon', 1.0),
  },
  {
    id: 'twilight_fireflies',
    partNumber: 9,
    name: 'Twilight Fireflies',
    animalTopics: 'Cats · Bats · Nocturnal Hunters',
    subtitle: 'Indigo dusk horizon, still mirror lake & glowing fireflies',
    treeStyle: 'pine',
    wildlife: 'butterflies',
    particles: 'fireflies',
    palette: {
      skyTop: '#0F172A',
      skyHorizon: '#3B4275',
      fog: '#293059',
      sun: '#E2E8F0',
      terrainLow: '#1C2E36',
      terrainHigh: '#2A434C',
      water: '#1A2B45',
      road: '#2A3042',
      foliageA: '#1B383B',
      foliageB: '#284C4D',
      trunk: '#292226',
      rock: '#3D4454',
      particle: '#FDE047',
      accent: '#FACC15',
    },
    terrainAmplitude: 4.2,
    waterLevel: -1.1,
    fogDensity: 0.011,
    stages: createBiomeStages('twilight_fireflies', 0.75),
  },
  {
    id: 'alpine_clouds',
    partNumber: 10,
    name: 'Alpine Cloud Peaks',
    animalTopics: 'Eagles · Falcons · High-Altitude Birds',
    subtitle: 'Soaring mountain summits above sculpted 3D cloud banks',
    treeStyle: 'snow_pine',
    wildlife: 'birds',
    particles: 'mist',
    palette: {
      skyTop: '#1D4ED8',
      skyHorizon: '#FDBA74',
      fog: '#E4C7B8',
      sun: '#FFF3D1',
      terrainLow: '#4B5E73',
      terrainHigh: '#E2E8F0',
      water: '#60A5FA',
      road: '#4E5B6E',
      foliageA: '#355461',
      foliageB: '#CBD5E1',
      trunk: '#473D38',
      rock: '#64748B',
      particle: '#FFF7ED',
      accent: '#F59E0B',
    },
    terrainAmplitude: 8.6,
    waterLevel: -3.8,
    fogDensity: 0.008,
    stages: createBiomeStages('alpine_clouds', 1.1),
  },
];
