import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import {
  BiomeDefinition,
  BiomeStage,
  TreeStyle,
  WildlifeType,
} from '../data/biomes';

// Module-scope reusable scratch objects (Zero GC inside animation loop)
const _colorA = new THREE.Color();
const _colorB = new THREE.Color();
const _sunPos = new THREE.Vector3();
const _lookTarget = new THREE.Vector3();

function detectSoftwareWebGL(): boolean {
  try {
    const canvas = document.createElement('canvas');
    const gl = canvas.getContext('webgl2') || canvas.getContext('webgl');
    if (!gl) return true;
    const ext = gl.getExtension('WEBGL_debug_renderer_info');
    const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
    const gpu = String(gl.getParameter(param) || '');
    gl.getExtension('WEBGL_lose_context')?.loseContext();
    return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
  } catch {
    return true;
  }
}

function createSoftParticleTexture(): THREE.CanvasTexture {
  const size = 64;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;
  const grad = ctx.createRadialGradient(size / 2, size / 2, 1, size / 2, size / 2, size / 2);
  grad.addColorStop(0, 'rgba(255,255,255,1)');
  grad.addColorStop(0.45, 'rgba(255,255,255,0.65)');
  grad.addColorStop(1, 'rgba(255,255,255,0)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, size, size);
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function createRoadTexture(maxAnisotropy: number): THREE.CanvasTexture {
  const w = 256;
  const h = 512;
  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext('2d')!;

  // Base neutral light-gray surface (tinted cleanly per biome via material.color)
  ctx.fillStyle = '#DCDCDC';
  ctx.fillRect(0, 0, w, h);

  // Subtle stylized texture grain
  for (let i = 0; i < 650; i++) {
    const gx = Math.random() * w;
    const gy = Math.random() * h;
    ctx.fillStyle = i % 2 === 0 ? 'rgba(255,255,255,0.08)' : 'rgba(0,0,0,0.08)';
    ctx.fillRect(gx, gy, 3, 6);
  }

  // Darker textured shoulders along left & right edges
  ctx.fillStyle = 'rgba(0,0,0,0.28)';
  ctx.fillRect(0, 0, 22, h);
  ctx.fillRect(w - 22, 0, 22, h);

  // Crisp outer edge lines
  ctx.fillStyle = 'rgba(255,255,255,0.42)';
  ctx.fillRect(26, 0, 5, h);
  ctx.fillRect(w - 31, 0, 5, h);

  // Dashed center lane stripe
  ctx.fillStyle = '#F7DF9C';
  ctx.fillRect(w / 2 - 5, 48, 10, 175);
  ctx.fillRect(w / 2 - 5, 304, 10, 175);

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.ClampToEdgeWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.anisotropy = maxAnisotropy;
  return tex;
}

// Smooth winding road centerline X at world Z
function roadCenterX(wz: number): number {
  return Math.sin(wz * 0.022) * 8.5 + Math.cos(wz * 0.011) * 4.0;
}

// Smooth rolling road elevation at world Z, safely above water
function roadElevation(wz: number, amplitude: number, waterLevel: number): number {
  const hill =
    Math.sin(wz * 0.018) * (amplitude * 0.25) +
    Math.cos(wz * 0.009) * (amplitude * 0.14);
  return Math.max(hill, waterLevel + 0.65);
}

// Deterministic terrain height carved smoothly around the winding roadbed
function sampleHeight(wx: number, wz: number, amplitude: number, waterLevel: number): number {
  const rx = roadCenterX(wz);
  const ry = roadElevation(wz, amplitude, waterLevel);
  const dist = Math.abs(wx - rx);

  const macro =
    Math.sin(wx * 0.05 + wz * 0.024) * 0.52 +
    Math.cos(wz * 0.044 - wx * 0.02) * 0.48;
  const detail =
    Math.sin(wx * 0.13 + wz * 0.11) * 0.22 +
    Math.cos(wx * 0.09 - wz * 0.14) * 0.16;
  const ridge = Math.abs(Math.sin(wx * 0.026 + wz * 0.032)) * 0.6;
  const terrainNatural = (macro + detail + ridge) * amplitude;

  // Smooth transition from flat roadbed (dist <= 4.3) to dense flanking hills (dist >= 16)
  const blend = THREE.MathUtils.smoothstep(dist, 4.3, 16.0);
  const roadBedY = ry - 0.14;
  return THREE.MathUtils.lerp(roadBedY, terrainNatural + amplitude * 0.15, blend);
}

interface PropSlot {
  sideOffset: number; // lateral offset relative to roadCenterX(wz)
  z: number;
  scale: number;
  rotY: number;
  group: THREE.Group;
}

interface WildlifeActor {
  group: THREE.Group;
  leftWing: THREE.Object3D;
  rightWing: THREE.Object3D;
  tail?: THREE.Object3D;
  sideOffset: number;
  baseY: number;
  baseZ: number;
  speed: number;
  phase: number;
  orbitR: number;
}

export class NatureWorld3D {
  private container: HTMLElement;
  private renderer: THREE.WebGLRenderer;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private isSoftwareGl: boolean;

  private sunLight: THREE.DirectionalLight;
  private rimLight: THREE.DirectionalLight;
  private hemiLight: THREE.HemisphereLight;
  private fog: THREE.FogExp2;

  private skyMaterial: THREE.ShaderMaterial;
  private sunDisc: THREE.Mesh;
  private terrainGeo: THREE.PlaneGeometry;
  private terrainMat: THREE.MeshStandardMaterial;
  private terrainMesh: THREE.Mesh;
  private roadGeo: THREE.PlaneGeometry;
  private roadBaseLocalX: Float32Array;
  private roadTexture: THREE.CanvasTexture;
  private roadMat: THREE.MeshStandardMaterial;
  private roadMesh: THREE.Mesh;
  private waterGeo: THREE.PlaneGeometry;
  private waterMat: THREE.MeshStandardMaterial;
  private waterMesh: THREE.Mesh;

  private foliageMatA: THREE.MeshStandardMaterial;
  private foliageMatB: THREE.MeshStandardMaterial;
  private trunkMat: THREE.MeshStandardMaterial;
  private rockMat: THREE.MeshStandardMaterial;
  private lanternGlowMat: THREE.MeshStandardMaterial;
  private cloudMat: THREE.MeshStandardMaterial;
  private wildlifeMat: THREE.MeshStandardMaterial;
  private wildlifeAccentMat: THREE.MeshStandardMaterial;

  private treeSlots: PropSlot[] = [];
  private bushSlots: PropSlot[] = [];
  private postSlots: PropSlot[] = [];
  private rockSlots: PropSlot[] = [];
  private cloudSlots: PropSlot[] = [];
  private wildlifeActors: WildlifeActor[] = [];

  private particleGeo: THREE.BufferGeometry;
  private particleMat: THREE.PointsMaterial;
  private particlePoints: THREE.Points;
  private particleCount = 280;
  private particlePositions: Float32Array;
  private particleTexture: THREE.CanvasTexture;

  private currentBiome: BiomeDefinition;
  private currentStage: BiomeStage;
  private isPlaying = true;

  // Smoothly interpolated live parameters
  private liveAmp: number;
  private liveWaterY: number;
  private liveSunElev: number;
  private liveFogDensity: number;
  private liveSkyTop = new THREE.Color();
  private liveSkyHorizon = new THREE.Color();
  private liveFogColor = new THREE.Color();
  private liveSunColor = new THREE.Color();
  private liveTerrainLow = new THREE.Color();
  private liveTerrainHigh = new THREE.Color();
  private liveWaterColor = new THREE.Color();
  private liveRoadColor = new THREE.Color();
  private liveFoliageA = new THREE.Color();
  private liveFoliageB = new THREE.Color();
  private liveTrunkColor = new THREE.Color();
  private liveRockColor = new THREE.Color();
  private liveParticleColor = new THREE.Color();

  private travelZ = 0;
  private elapsedSec = 0;
  private frameId = 0;
  private lastNow = performance.now();
  private disposed = false;
  private resizeObserver: ResizeObserver;
  private onContextLostCb?: () => void;
  private onContextRestoredCb?: () => void;

  constructor(
    container: HTMLElement,
    initialBiome: BiomeDefinition,
    initialStage: BiomeStage,
    callbacks?: { onContextLost?: () => void; onContextRestored?: () => void }
  ) {
    this.container = container;
    this.currentBiome = initialBiome;
    this.currentStage = initialStage;
    this.onContextLostCb = callbacks?.onContextLost;
    this.onContextRestoredCb = callbacks?.onContextRestored;

    this.liveAmp = initialBiome.terrainAmplitude;
    this.liveWaterY = initialBiome.waterLevel;
    this.liveSunElev = initialStage.sunElevation;
    this.liveFogDensity = initialBiome.fogDensity;

    this.liveSkyTop.set(initialBiome.palette.skyTop);
    this.liveSkyHorizon.set(initialBiome.palette.skyHorizon);
    this.liveFogColor.set(initialBiome.palette.fog);
    this.liveSunColor.set(initialBiome.palette.sun);
    this.liveTerrainLow.set(initialBiome.palette.terrainLow);
    this.liveTerrainHigh.set(initialBiome.palette.terrainHigh);
    this.liveWaterColor.set(initialBiome.palette.water);
    this.liveRoadColor.set(initialBiome.palette.road);
    this.liveFoliageA.set(initialBiome.palette.foliageA);
    this.liveFoliageB.set(initialBiome.palette.foliageB);
    this.liveTrunkColor.set(initialBiome.palette.trunk);
    this.liveRockColor.set(initialBiome.palette.rock);
    this.liveParticleColor.set(initialBiome.palette.particle);

    this.isSoftwareGl = detectSoftwareWebGL();
    this.renderer = new THREE.WebGLRenderer({
      antialias: !this.isSoftwareGl,
      powerPreference: 'high-performance',
    });
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.08;
    this.renderer.setPixelRatio(
      this.isSoftwareGl ? 1 : Math.min(window.devicePixelRatio || 1, 2)
    );
    this.renderer.shadowMap.enabled = !this.isSoftwareGl;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.domElement.style.width = '100%';
    this.renderer.domElement.style.height = '100%';
    this.renderer.domElement.style.display = 'block';
    this.container.appendChild(this.renderer.domElement);

    this.renderer.domElement.addEventListener('webglcontextlost', this.handleContextLost);
    this.renderer.domElement.addEventListener('webglcontextrestored', this.handleContextRestored);

    this.scene = new THREE.Scene();
    this.fog = new THREE.FogExp2(this.liveFogColor.getHex(), this.liveFogDensity);
    this.scene.fog = this.fog;

    const w = Math.max(1, container.clientWidth);
    const h = Math.max(1, container.clientHeight);
    this.camera = new THREE.PerspectiveCamera(50, w / h, 0.3, 320);
    this.camera.position.set(roadCenterX(14), 4.6, 14);
    this.renderer.setSize(w, h, false);

    // Mandatory studio environment map for PBR reflections
    const pmrem = new THREE.PMREMGenerator(this.renderer);
    const envScene = new RoomEnvironment();
    this.scene.environment = pmrem.fromScene(envScene, 0.04).texture;
    envScene.dispose();
    pmrem.dispose();

    // 3-point outdoor lighting rig
    this.hemiLight = new THREE.HemisphereLight(
      this.liveSkyHorizon.getHex(),
      this.liveTerrainLow.getHex(),
      0.85
    );
    this.scene.add(this.hemiLight);

    this.sunLight = new THREE.DirectionalLight(this.liveSunColor.getHex(), 1.65);
    this.sunLight.position.set(24, 32, -45);
    this.sunLight.castShadow = !this.isSoftwareGl;
    this.sunLight.shadow.mapSize.set(1024, 1024);
    this.sunLight.shadow.camera.near = 2;
    this.sunLight.shadow.camera.far = 160;
    const d = 52;
    this.sunLight.shadow.camera.left = -d;
    this.sunLight.shadow.camera.right = d;
    this.sunLight.shadow.camera.top = d;
    this.sunLight.shadow.camera.bottom = -d;
    this.sunLight.shadow.bias = -0.0005;
    this.sunLight.shadow.normalBias = 0.02;
    this.scene.add(this.sunLight);

    this.rimLight = new THREE.DirectionalLight(0xffffff, 0.45);
    this.rimLight.position.set(-20, 14, 24);
    this.scene.add(this.rimLight);

    // Gradient Sky Dome
    this.skyMaterial = new THREE.ShaderMaterial({
      side: THREE.BackSide,
      depthWrite: false,
      fog: false,
      uniforms: {
        uTopColor: { value: this.liveSkyTop.clone() },
        uHorizonColor: { value: this.liveSkyHorizon.clone() },
        uSunColor: { value: this.liveSunColor.clone() },
        uSunDir: { value: new THREE.Vector3(0.2, 0.35, -0.9).normalize() },
      },
      vertexShader: `
        varying vec3 vWorldDir;
        void main() {
          vec4 worldPos = modelMatrix * vec4(position, 1.0);
          vWorldDir = normalize(position);
          gl_Position = projectionMatrix * viewMatrix * worldPos;
        }
      `,
      fragmentShader: `
        uniform vec3 uTopColor;
        uniform vec3 uHorizonColor;
        uniform vec3 uSunColor;
        uniform vec3 uSunDir;
        varying vec3 vWorldDir;
        void main() {
          vec3 dir = normalize(vWorldDir);
          float h = clamp(dir.y * 1.35 + 0.08, 0.0, 1.0);
          vec3 sky = mix(uHorizonColor, uTopColor, pow(h, 0.65));
          float sunDot = max(dot(dir, normalize(uSunDir)), 0.0);
          float halo = pow(sunDot, 10.0) * 0.38 + pow(sunDot, 80.0) * 0.55;
          sky += uSunColor * halo;
          gl_FragColor = vec4(sky, 1.0);
        }
      `,
    });
    const skyDome = new THREE.Mesh(new THREE.SphereGeometry(220, 32, 20), this.skyMaterial);
    this.scene.add(skyDome);

    // Glowing sun/moon disc
    this.sunDisc = new THREE.Mesh(
      new THREE.SphereGeometry(6.5, 24, 16),
      new THREE.MeshBasicMaterial({ color: this.liveSunColor, fog: false })
    );
    this.scene.add(this.sunDisc);

    // Stylized vertex-colored terrain flanking the road
    this.terrainGeo = new THREE.PlaneGeometry(210, 175, 80, 68);
    this.terrainGeo.rotateX(-Math.PI / 2);
    const vertCount = this.terrainGeo.attributes.position.count;
    this.terrainGeo.setAttribute(
      'color',
      new THREE.BufferAttribute(new Float32Array(vertCount * 3), 3)
    );
    this.terrainMat = new THREE.MeshStandardMaterial({
      vertexColors: true,
      roughness: 0.88,
      metalness: 0.04,
      flatShading: true,
    });
    this.terrainMesh = new THREE.Mesh(this.terrainGeo, this.terrainMat);
    this.terrainMesh.position.set(0, 0, -45);
    this.terrainMesh.receiveShadow = true;
    this.scene.add(this.terrainMesh);

    // Continuous winding 3D road ribbon
    this.roadGeo = new THREE.PlaneGeometry(8.2, 175, 8, 92);
    this.roadGeo.rotateX(-Math.PI / 2);
    const rPos = this.roadGeo.attributes.position as THREE.BufferAttribute;
    this.roadBaseLocalX = new Float32Array(rPos.count);
    for (let i = 0; i < rPos.count; i++) {
      this.roadBaseLocalX[i] = rPos.getX(i);
    }
    this.roadTexture = createRoadTexture(this.renderer.capabilities.getMaxAnisotropy());
    this.roadMat = new THREE.MeshStandardMaterial({
      color: this.liveRoadColor,
      map: this.roadTexture,
      roughness: 0.82,
      metalness: 0.06,
      polygonOffset: true,
      polygonOffsetFactor: -1,
      polygonOffsetUnits: -1,
    });
    this.roadMesh = new THREE.Mesh(this.roadGeo, this.roadMat);
    this.roadMesh.position.set(0, 0, -45);
    this.roadMesh.receiveShadow = true;
    this.scene.add(this.roadMesh);

    // Translucent stylized water plane
    this.waterGeo = new THREE.PlaneGeometry(210, 175, 40, 34);
    this.waterGeo.rotateX(-Math.PI / 2);
    this.waterMat = new THREE.MeshStandardMaterial({
      color: this.liveWaterColor,
      roughness: 0.16,
      metalness: 0.22,
      flatShading: true,
      transparent: true,
      opacity: 0.82,
    });
    this.waterMesh = new THREE.Mesh(this.waterGeo, this.waterMat);
    this.waterMesh.position.set(0, this.liveWaterY, -45);
    this.waterMesh.receiveShadow = true;
    this.scene.add(this.waterMesh);

    // Shared stylized PBR materials with varied roughness
    this.foliageMatA = new THREE.MeshStandardMaterial({
      color: this.liveFoliageA,
      roughness: 0.78,
      metalness: 0.02,
      flatShading: true,
    });
    this.foliageMatB = new THREE.MeshStandardMaterial({
      color: this.liveFoliageB,
      roughness: 0.7,
      metalness: 0.04,
      flatShading: true,
    });
    this.trunkMat = new THREE.MeshStandardMaterial({
      color: this.liveTrunkColor,
      roughness: 0.92,
      metalness: 0.0,
      flatShading: true,
    });
    this.rockMat = new THREE.MeshStandardMaterial({
      color: this.liveRockColor,
      roughness: 0.85,
      metalness: 0.08,
      flatShading: true,
    });
    this.lanternGlowMat = new THREE.MeshStandardMaterial({
      color: 0xffe49e,
      emissive: 0xffb347,
      emissiveIntensity: 0.85,
      roughness: 0.35,
      metalness: 0.05,
    });
    this.cloudMat = new THREE.MeshStandardMaterial({
      color: 0xffffff,
      roughness: 0.92,
      metalness: 0.0,
      flatShading: true,
      transparent: true,
      opacity: 0.92,
    });
    this.wildlifeMat = new THREE.MeshStandardMaterial({
      color: 0xf8fafc,
      roughness: 0.45,
      metalness: 0.1,
      flatShading: true,
    });
    this.wildlifeAccentMat = new THREE.MeshStandardMaterial({
      color: new THREE.Color(initialBiome.palette.accent),
      roughness: 0.35,
      metalness: 0.15,
      flatShading: true,
    });

    this.populateTrees(initialBiome.treeStyle);
    this.populateBushes();
    this.populateRoadsidePosts();
    this.populateRocks();
    this.populateClouds();
    this.populateWildlife(initialBiome.wildlife);

    // Atmospheric particles
    this.particleTexture = createSoftParticleTexture();
    this.particlePositions = new Float32Array(this.particleCount * 3);
    for (let i = 0; i < this.particleCount; i++) {
      this.particlePositions[i * 3] = (Math.random() - 0.5) * 90;
      this.particlePositions[i * 3 + 1] = Math.random() * 20;
      this.particlePositions[i * 3 + 2] = -Math.random() * 115 + 18;
    }
    this.particleGeo = new THREE.BufferGeometry();
    this.particleGeo.setAttribute(
      'position',
      new THREE.BufferAttribute(this.particlePositions, 3)
    );
    this.particleMat = new THREE.PointsMaterial({
      color: this.liveParticleColor,
      size: 0.52,
      map: this.particleTexture,
      transparent: true,
      opacity: 0.85,
      depthWrite: false,
      blending: THREE.NormalBlending,
    });
    this.particlePoints = new THREE.Points(this.particleGeo, this.particleMat);
    this.scene.add(this.particlePoints);

    this.updateTerrainAndRoadVertices();
    this.syncPropHeights();

    if (!this.isSoftwareGl) {
      this.renderer.compile(this.scene, this.camera);
    }

    this.resizeObserver = new ResizeObserver(() => this.handleResize());
    this.resizeObserver.observe(this.container);

    this.lastNow = performance.now();
    this.scheduleNextTick();
  }

  private handleContextLost = (e: Event) => {
    e.preventDefault();
    this.onContextLostCb?.();
  };

  private handleContextRestored = () => {
    this.onContextRestoredCb?.();
  };

  public handleResize() {
    if (this.disposed) return;
    const w = Math.max(1, this.container.clientWidth);
    const h = Math.max(1, this.container.clientHeight);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h, false);
  }

  public setPlaying(playing: boolean) {
    this.isPlaying = playing;
    if (playing) {
      this.lastNow = performance.now();
    }
  }

  public setSceneTarget(biome: BiomeDefinition, stage: BiomeStage) {
    const prevTree = this.currentBiome.treeStyle;
    const prevWild = this.currentBiome.wildlife;
    this.currentBiome = biome;
    this.currentStage = stage;
    this.wildlifeAccentMat.color.set(biome.palette.accent);

    if (prevTree !== biome.treeStyle) {
      this.rebuildTreeMeshes(biome.treeStyle);
    }
    if (prevWild !== biome.wildlife) {
      this.rebuildWildlifeMeshes(biome.wildlife);
    }
  }

  private createTreeGroup(style: TreeStyle): THREE.Group {
    const g = new THREE.Group();

    if (style === 'pine' || style === 'snow_pine') {
      const trunk = new THREE.Mesh(
        new THREE.CylinderGeometry(0.2, 0.36, 2.3, 6),
        this.trunkMat
      );
      trunk.position.y = 1.15;
      trunk.castShadow = true;
      g.add(trunk);

      const tier1 = new THREE.Mesh(new THREE.ConeGeometry(1.75, 2.7, 7), this.foliageMatA);
      tier1.position.y = 2.9;
      tier1.castShadow = true;
      g.add(tier1);

      const tier2 = new THREE.Mesh(new THREE.ConeGeometry(1.35, 2.4, 7), this.foliageMatB);
      tier2.position.y = 4.35;
      tier2.castShadow = true;
      g.add(tier2);

      const tier3 = new THREE.Mesh(
        new THREE.ConeGeometry(0.9, 1.9, 7),
        style === 'snow_pine' ? this.foliageMatB : this.foliageMatA
      );
      tier3.position.y = 5.6;
      tier3.castShadow = true;
      g.add(tier3);
    } else if (style === 'acacia') {
      const trunk = new THREE.Mesh(
        new THREE.CylinderGeometry(0.2, 0.38, 3.2, 6),
        this.trunkMat
      );
      trunk.position.y = 1.6;
      trunk.rotation.z = 0.08;
      trunk.castShadow = true;
      g.add(trunk);

      const branch = new THREE.Mesh(
        new THREE.CylinderGeometry(0.1, 0.16, 1.8, 5),
        this.trunkMat
      );
      branch.position.set(0.55, 2.9, 0.1);
      branch.rotation.z = -0.55;
      g.add(branch);

      const cap1 = new THREE.Mesh(
        new THREE.CylinderGeometry(2.1, 1.4, 0.65, 8),
        this.foliageMatA
      );
      cap1.position.set(-0.2, 3.5, 0);
      cap1.castShadow = true;
      g.add(cap1);

      const cap2 = new THREE.Mesh(
        new THREE.CylinderGeometry(1.5, 0.9, 0.55, 7),
        this.foliageMatB
      );
      cap2.position.set(0.95, 3.85, 0.25);
      cap2.castShadow = true;
      g.add(cap2);
    } else if (style === 'palm') {
      for (let i = 0; i < 3; i++) {
        const seg = new THREE.Mesh(
          new THREE.CylinderGeometry(0.18 - i * 0.03, 0.22 - i * 0.03, 1.35, 6),
          this.trunkMat
        );
        seg.position.set(i * 0.18, 0.6 + i * 1.15, 0);
        seg.rotation.z = -0.08 * (i + 1);
        seg.castShadow = true;
        g.add(seg);
      }
      for (let i = 0; i < 6; i++) {
        const frond = new THREE.Mesh(
          new THREE.ConeGeometry(0.45, 2.5, 5),
          i % 2 === 0 ? this.foliageMatA : this.foliageMatB
        );
        const angle = (i / 6) * Math.PI * 2;
        frond.position.set(
          0.42 + Math.cos(angle) * 1.0,
          3.95,
          Math.sin(angle) * 1.0
        );
        frond.rotation.z = -Math.PI * 0.36;
        frond.rotation.y = -angle;
        frond.castShadow = true;
        g.add(frond);
      }
    } else if (style === 'coral') {
      const base = new THREE.Mesh(new THREE.DodecahedronGeometry(0.85, 0), this.rockMat);
      base.scale.set(1.2, 0.65, 1.1);
      base.position.y = 0.4;
      g.add(base);

      for (let i = 0; i < 4; i++) {
        const stem = new THREE.Mesh(
          new THREE.CylinderGeometry(0.24, 0.12, 1.8 + (i % 2) * 0.8, 6),
          i % 2 === 0 ? this.foliageMatA : this.foliageMatB
        );
        const a = (i / 4) * Math.PI * 2;
        stem.position.set(Math.cos(a) * 0.42, 1.25, Math.sin(a) * 0.42);
        stem.rotation.z = (i % 2 === 0 ? 1 : -1) * 0.24;
        stem.castShadow = true;
        g.add(stem);

        const bulb = new THREE.Mesh(
          new THREE.DodecahedronGeometry(0.38, 0),
          i % 2 === 0 ? this.foliageMatB : this.foliageMatA
        );
        bulb.position.set(Math.cos(a) * 0.55, 2.25 + (i % 2) * 0.3, Math.sin(a) * 0.55);
        g.add(bulb);
      }
    } else if (style === 'cactus') {
      const main = new THREE.Mesh(new THREE.CapsuleGeometry(0.32, 2.5, 4, 7), this.foliageMatA);
      main.position.y = 1.5;
      main.castShadow = true;
      g.add(main);

      const armL = new THREE.Mesh(new THREE.CapsuleGeometry(0.2, 1.1, 4, 6), this.foliageMatB);
      armL.position.set(-0.55, 1.75, 0);
      armL.rotation.z = 0.35;
      armL.castShadow = true;
      g.add(armL);

      const armR = new THREE.Mesh(new THREE.CapsuleGeometry(0.18, 0.9, 4, 6), this.foliageMatB);
      armR.position.set(0.52, 1.4, 0);
      armR.rotation.z = -0.35;
      armR.castShadow = true;
      g.add(armR);
    } else {
      const trunk = new THREE.Mesh(
        new THREE.CylinderGeometry(0.22, 0.38, 2.4, 6),
        this.trunkMat
      );
      trunk.position.y = 1.2;
      trunk.castShadow = true;
      g.add(trunk);

      const offsets: [number, number, number, number][] = [
        [0, 3.2, 0, 1.45],
        [-0.75, 2.85, 0.35, 1.05],
        [0.8, 2.9, -0.3, 1.0],
        [0.15, 3.85, 0.25, 0.95],
      ];
      offsets.forEach(([ox, oy, oz, r], idx) => {
        const puff = new THREE.Mesh(
          new THREE.DodecahedronGeometry(r, 1),
          idx % 2 === 0 ? this.foliageMatA : this.foliageMatB
        );
        puff.position.set(ox, oy, oz);
        puff.castShadow = true;
        g.add(puff);
      });
    }

    return g;
  }

  private populateTrees(style: TreeStyle) {
    const count = 88;
    for (let i = 0; i < count; i++) {
      const side = i % 2 === 0 ? 1 : -1;
      // Dense canopy flanking right outside the road shoulders (6.5m to 48m)
      const band = i % 3 === 0 ? 6.6 + Math.random() * 7.5 : 13.5 + Math.random() * 34;
      const sideOffset = side * band;
      const z = -112 + (i / count) * 140;
      const group = this.createTreeGroup(style);
      const scale = 0.9 + Math.random() * 0.85;
      group.scale.setScalar(scale);
      group.rotation.y = Math.random() * Math.PI * 2;
      this.scene.add(group);
      this.treeSlots.push({ sideOffset, z, scale, rotY: group.rotation.y, group });
    }
  }

  private rebuildTreeMeshes(style: TreeStyle) {
    for (const slot of this.treeSlots) {
      this.scene.remove(slot.group);
      slot.group.traverse((obj) => {
        if (obj instanceof THREE.Mesh) obj.geometry.dispose();
      });
      const next = this.createTreeGroup(style);
      next.scale.setScalar(slot.scale);
      next.rotation.y = slot.rotY;
      next.position.copy(slot.group.position);
      this.scene.add(next);
      slot.group = next;
    }
  }

  private populateBushes() {
    // Lush roadside jungle undergrowth / bushes along both edges of the road
    const count = 64;
    for (let i = 0; i < count; i++) {
      const g = new THREE.Group();
      for (let p = 0; p < 3; p++) {
        const bush = new THREE.Mesh(
          new THREE.DodecahedronGeometry(0.55 + (p % 2) * 0.2, 0),
          p % 2 === 0 ? this.foliageMatB : this.foliageMatA
        );
        bush.position.set((p - 1) * 0.48, 0.35 + (p === 1 ? 0.16 : 0), (p % 2) * 0.25);
        bush.scale.set(1.15, 0.85, 1.0);
        bush.castShadow = true;
        g.add(bush);
      }
      const side = i % 2 === 0 ? 1 : -1;
      const sideOffset = side * (4.7 + Math.random() * 5.2);
      const z = -112 + (i / count) * 140;
      const scale = 0.75 + Math.random() * 0.65;
      g.scale.setScalar(scale);
      g.rotation.y = Math.random() * Math.PI * 2;
      this.scene.add(g);
      this.bushSlots.push({ sideOffset, z, scale, rotY: g.rotation.y, group: g });
    }
  }

  private populateRoadsidePosts() {
    // Stylized wooden mileposts & warm glowing roadside lanterns lining both shoulders
    const count = 22;
    for (let i = 0; i < count; i++) {
      const g = new THREE.Group();
      const post = new THREE.Mesh(
        new THREE.CylinderGeometry(0.09, 0.12, 1.35, 6),
        this.trunkMat
      );
      post.position.y = 0.68;
      post.castShadow = true;
      g.add(post);

      const lantern = new THREE.Mesh(
        new THREE.BoxGeometry(0.22, 0.26, 0.22),
        this.lanternGlowMat
      );
      lantern.position.y = 1.42;
      g.add(lantern);

      const cap = new THREE.Mesh(
        new THREE.ConeGeometry(0.24, 0.18, 4),
        this.rockMat
      );
      cap.position.y = 1.62;
      cap.rotation.y = Math.PI / 4;
      g.add(cap);

      const side = i % 2 === 0 ? 1 : -1;
      const sideOffset = side * 4.45;
      const z = -110 + (i / count) * 138;
      this.scene.add(g);
      this.postSlots.push({ sideOffset, z, scale: 1, rotY: 0, group: g });
    }
  }

  private populateRocks() {
    for (let i = 0; i < 30; i++) {
      const g = new THREE.Group();
      const main = new THREE.Mesh(new THREE.DodecahedronGeometry(1.0, 0), this.rockMat);
      main.scale.set(1.3, 0.72, 1.0);
      main.position.y = 0.38;
      main.castShadow = true;
      main.receiveShadow = true;
      g.add(main);

      const chip = new THREE.Mesh(new THREE.DodecahedronGeometry(0.55, 0), this.rockMat);
      chip.position.set(0.8, 0.22, 0.32);
      chip.castShadow = true;
      g.add(chip);

      const side = i % 2 === 0 ? 1 : -1;
      const sideOffset = side * (5.6 + Math.random() * 28);
      const z = -112 + (i / 30) * 140;
      const scale = 0.65 + Math.random() * 1.05;
      g.scale.setScalar(scale);
      g.rotation.y = Math.random() * Math.PI * 2;
      this.scene.add(g);
      this.rockSlots.push({ sideOffset, z, scale, rotY: g.rotation.y, group: g });
    }
  }

  private populateClouds() {
    for (let i = 0; i < 16; i++) {
      const g = new THREE.Group();
      const puffs = 4 + (i % 3);
      for (let p = 0; p < puffs; p++) {
        const puff = new THREE.Mesh(
          new THREE.IcosahedronGeometry(1.6 + (p % 2) * 0.6, 1),
          this.cloudMat
        );
        puff.position.set((p - puffs / 2) * 1.45, Math.sin(p) * 0.4, (p % 2) * 0.6);
        puff.scale.set(1.2, 0.65, 0.9);
        g.add(puff);
      }
      const sideOffset = (Math.random() - 0.5) * 120;
      const z = -120 + (i / 16) * 145;
      const scale = 1.2 + Math.random() * 1.4;
      g.position.set(sideOffset, 22 + Math.random() * 12, z);
      g.scale.setScalar(scale);
      this.scene.add(g);
      this.cloudSlots.push({ sideOffset, z, scale, rotY: 0, group: g });
    }
  }

  private createWildlifeActor(type: WildlifeType, idx: number): WildlifeActor {
    const group = new THREE.Group();
    let leftWing: THREE.Object3D = new THREE.Object3D();
    let rightWing: THREE.Object3D = new THREE.Object3D();
    let tail: THREE.Object3D | undefined;

    if (type === 'fish') {
      const body = new THREE.Mesh(new THREE.SphereGeometry(0.32, 10, 8), this.wildlifeAccentMat);
      body.scale.set(0.65, 0.85, 1.8);
      group.add(body);

      const dorsal = new THREE.Mesh(new THREE.ConeGeometry(0.14, 0.35, 4), this.wildlifeMat);
      dorsal.position.set(0, 0.3, -0.05);
      dorsal.rotation.x = -0.35;
      group.add(dorsal);

      const tailMesh = new THREE.Mesh(new THREE.ConeGeometry(0.24, 0.45, 4), this.wildlifeMat);
      tailMesh.rotation.x = Math.PI / 2;
      tailMesh.position.z = -0.62;
      group.add(tailMesh);
      tail = tailMesh;
    } else if (type === 'butterflies') {
      const body = new THREE.Mesh(new THREE.CapsuleGeometry(0.05, 0.28, 3, 5), this.trunkMat);
      body.rotation.x = Math.PI / 2;
      group.add(body);

      const wingGeo = new THREE.CircleGeometry(0.28, 5);
      wingGeo.translate(0.22, 0, 0);
      const lMesh = new THREE.Mesh(wingGeo, this.wildlifeAccentMat);
      lMesh.rotation.x = -Math.PI / 2;
      const rMesh = new THREE.Mesh(wingGeo, this.wildlifeAccentMat);
      rMesh.rotation.x = -Math.PI / 2;
      rMesh.scale.x = -1;

      leftWing.add(lMesh);
      rightWing.add(rMesh);
      group.add(leftWing, rightWing);
    } else {
      const body = new THREE.Mesh(new THREE.ConeGeometry(0.16, 0.72, 6), this.wildlifeMat);
      body.rotation.x = -Math.PI / 2;
      group.add(body);

      const head = new THREE.Mesh(new THREE.SphereGeometry(0.13, 8, 6), this.wildlifeMat);
      head.position.set(0, 0.06, -0.35);
      group.add(head);

      const beak = new THREE.Mesh(new THREE.ConeGeometry(0.05, 0.16, 5), this.wildlifeAccentMat);
      beak.rotation.x = -Math.PI / 2;
      beak.position.set(0, 0.05, -0.48);
      group.add(beak);

      const wingGeo = new THREE.BoxGeometry(0.65, 0.04, 0.24);
      wingGeo.translate(0.32, 0, 0);
      const lWingMesh = new THREE.Mesh(wingGeo, this.wildlifeMat);
      leftWing.add(lWingMesh);

      const rWingGeo = new THREE.BoxGeometry(0.65, 0.04, 0.24);
      rWingGeo.translate(-0.32, 0, 0);
      const rWingMesh = new THREE.Mesh(rWingGeo, this.wildlifeMat);
      rightWing.add(rWingMesh);

      group.add(leftWing, rightWing);
    }

    const sideOffset = (Math.random() - 0.5) * 24;
    const baseY = type === 'fish' ? 2.5 + Math.random() * 4.5 : 5.5 + Math.random() * 8;
    const baseZ = -18 - idx * 5.2;
    group.position.set(sideOffset, baseY, baseZ);
    this.scene.add(group);

    return {
      group,
      leftWing,
      rightWing,
      tail,
      sideOffset,
      baseY,
      baseZ,
      speed: 0.9 + Math.random() * 0.7,
      phase: Math.random() * Math.PI * 2,
      orbitR: 3 + Math.random() * 4.5,
    };
  }

  private populateWildlife(type: WildlifeType) {
    for (let i = 0; i < 12; i++) {
      this.wildlifeActors.push(this.createWildlifeActor(type, i));
    }
  }

  private rebuildWildlifeMeshes(type: WildlifeType) {
    for (const actor of this.wildlifeActors) {
      this.scene.remove(actor.group);
      actor.group.traverse((obj) => {
        if (obj instanceof THREE.Mesh) obj.geometry.dispose();
      });
    }
    this.wildlifeActors = [];
    this.populateWildlife(type);
  }

  private updateTerrainAndRoadVertices() {
    // 1. Update flanking terrain mesh vertices & heights
    const pos = this.terrainGeo.attributes.position as THREE.BufferAttribute;
    const col = this.terrainGeo.attributes.color as THREE.BufferAttribute;
    const count = pos.count;

    for (let i = 0; i < count; i++) {
      const lx = pos.getX(i);
      const lz = pos.getZ(i);
      const wz = lz - this.travelZ - 45;
      const h = sampleHeight(lx, wz, this.liveAmp, this.liveWaterY);
      pos.setY(i, h);

      const normH = THREE.MathUtils.clamp((h + this.liveAmp) / (this.liveAmp * 2.2), 0, 1);
      _colorA.copy(this.liveTerrainLow).lerp(this.liveTerrainHigh, normH);
      col.setXYZ(i, _colorA.r, _colorA.g, _colorA.b);
    }
    pos.needsUpdate = true;
    col.needsUpdate = true;
    this.terrainGeo.computeVertexNormals();

    // 2. Update winding road ribbon vertices & scrolling dashed-line UVs
    const rPos = this.roadGeo.attributes.position as THREE.BufferAttribute;
    const rUv = this.roadGeo.attributes.uv as THREE.BufferAttribute;
    for (let i = 0; i < rPos.count; i++) {
      const localX = this.roadBaseLocalX[i];
      const lz = rPos.getZ(i);
      const wz = lz - this.travelZ - 45;
      const rx = roadCenterX(wz);
      const ry = roadElevation(wz, this.liveAmp, this.liveWaterY);
      rPos.setX(i, rx + localX);
      rPos.setY(i, ry + 0.06);
      rUv.setY(i, -wz * 0.065);
    }
    rPos.needsUpdate = true;
    rUv.needsUpdate = true;
    this.roadGeo.computeVertexNormals();

    // 3. Water ripples
    const wPos = this.waterGeo.attributes.position as THREE.BufferAttribute;
    for (let i = 0; i < wPos.count; i++) {
      const wx = wPos.getX(i);
      const wz = wPos.getZ(i);
      const ripple =
        Math.sin(wx * 0.25 + this.elapsedSec * 1.4) * 0.14 +
        Math.cos((wz - this.travelZ) * 0.22 - this.elapsedSec * 1.1) * 0.12;
      wPos.setY(i, ripple);
    }
    wPos.needsUpdate = true;
  }

  private syncPropHeights() {
    const placeOnRoadside = (slot: PropSlot, yOffset: number) => {
      const wz = slot.z - this.travelZ;
      const x = roadCenterX(wz) + slot.sideOffset;
      const y = sampleHeight(x, wz, this.liveAmp, this.liveWaterY);
      slot.group.position.set(x, y + yOffset, slot.z);
    };

    for (const slot of this.treeSlots) placeOnRoadside(slot, -0.18);
    for (const slot of this.bushSlots) placeOnRoadside(slot, -0.12);
    for (const slot of this.rockSlots) placeOnRoadside(slot, -0.15);

    for (const slot of this.postSlots) {
      const wz = slot.z - this.travelZ;
      const x = roadCenterX(wz) + slot.sideOffset;
      const y = roadElevation(wz, this.liveAmp, this.liveWaterY);
      slot.group.position.set(x, y - 0.05, slot.z);
    }
  }

  private stepSimulation(dt: number) {
    const speedFactor = this.isPlaying ? this.currentStage.cameraSpeed : 0;
    this.elapsedSec += dt * (this.isPlaying ? 1 : 0);
    const roadSpeed = 10.5 * speedFactor;
    this.travelZ += dt * roadSpeed;

    // Smoothly damp biome colors & atmosphere
    const k = 1.6;
    const p = this.currentBiome.palette;
    _colorB.set(p.skyTop);
    this.liveSkyTop.lerp(_colorB, 1 - Math.exp(-k * dt));
    _colorB.set(p.skyHorizon);
    this.liveSkyHorizon.lerp(_colorB, 1 - Math.exp(-k * dt));
    _colorB.set(p.fog);
    this.liveFogColor.lerp(_colorB, 1 - Math.exp(-k * dt));
    _colorB.set(p.sun);
    this.liveSunColor.lerp(_colorB, 1 - Math.exp(-k * dt));
    _colorB.set(p.terrainLow);
    this.liveTerrainLow.lerp(_colorB, 1 - Math.exp(-k * dt));
    _colorB.set(p.terrainHigh);
    this.liveTerrainHigh.lerp(_colorB, 1 - Math.exp(-k * dt));
    _colorB.set(p.water);
    this.liveWaterColor.lerp(_colorB, 1 - Math.exp(-k * dt));
    _colorB.set(p.road);
    this.liveRoadColor.lerp(_colorB, 1 - Math.exp(-k * dt));
    _colorB.set(p.foliageA);
    this.liveFoliageA.lerp(_colorB, 1 - Math.exp(-k * dt));
    _colorB.set(p.foliageB);
    this.liveFoliageB.lerp(_colorB, 1 - Math.exp(-k * dt));
    _colorB.set(p.trunk);
    this.liveTrunkColor.lerp(_colorB, 1 - Math.exp(-k * dt));
    _colorB.set(p.rock);
    this.liveRockColor.lerp(_colorB, 1 - Math.exp(-k * dt));
    _colorB.set(p.particle);
    this.liveParticleColor.lerp(_colorB, 1 - Math.exp(-k * dt));

    this.liveAmp = THREE.MathUtils.damp(this.liveAmp, this.currentBiome.terrainAmplitude, k, dt);
    this.liveWaterY = THREE.MathUtils.damp(this.liveWaterY, this.currentBiome.waterLevel, k, dt);
    this.liveSunElev = THREE.MathUtils.damp(
      this.liveSunElev,
      this.currentStage.sunElevation,
      k,
      dt
    );
    this.liveFogDensity = THREE.MathUtils.damp(
      this.liveFogDensity,
      this.currentBiome.fogDensity,
      k,
      dt
    );

    // Push damped values into scene materials/lights
    this.fog.color.copy(this.liveFogColor);
    this.fog.density = this.liveFogDensity;
    this.skyMaterial.uniforms.uTopColor.value.copy(this.liveSkyTop);
    this.skyMaterial.uniforms.uHorizonColor.value.copy(this.liveSkyHorizon);
    this.skyMaterial.uniforms.uSunColor.value.copy(this.liveSunColor);

    const elevRad = THREE.MathUtils.degToRad(this.liveSunElev);
    const sunAz = Math.sin(this.elapsedSec * 0.035) * 0.3;
    _sunPos.set(
      Math.sin(sunAz) * Math.cos(elevRad),
      Math.sin(elevRad),
      -Math.cos(sunAz) * Math.cos(elevRad)
    );
    this.skyMaterial.uniforms.uSunDir.value.copy(_sunPos);
    this.sunDisc.position.copy(_sunPos).multiplyScalar(170);
    (this.sunDisc.material as THREE.MeshBasicMaterial).color.copy(this.liveSunColor);

    this.sunLight.position.copy(_sunPos).multiplyScalar(65);
    this.sunLight.color.copy(this.liveSunColor);
    this.sunLight.intensity = 1.45 * this.currentStage.ambientBoost;
    this.hemiLight.color.copy(this.liveSkyHorizon);
    this.hemiLight.groundColor.copy(this.liveTerrainLow);

    this.waterMat.color.copy(this.liveWaterColor);
    this.waterMesh.position.y = this.liveWaterY;
    this.roadMat.color.copy(this.liveRoadColor);
    this.foliageMatA.color.copy(this.liveFoliageA);
    this.foliageMatB.color.copy(this.liveFoliageB);
    this.trunkMat.color.copy(this.liveTrunkColor);
    this.rockMat.color.copy(this.liveRockColor);
    this.particleMat.color.copy(this.liveParticleColor);

    const showClouds = !this.currentBiome.isUnderwater;
    this.cloudMat.opacity = THREE.MathUtils.damp(
      this.cloudMat.opacity,
      showClouds ? 0.9 : 0.0,
      2.5,
      dt
    );

    // Wrap flanking jungle trees, bushes, rocks & posts smoothly along +Z treadmill
    const forwardStep = dt * roadSpeed;
    for (const slot of this.treeSlots) {
      slot.z += forwardStep;
      if (slot.z > 28) slot.z -= 140;
      slot.group.rotation.z = Math.sin(this.elapsedSec * 1.4 + slot.sideOffset) * 0.025;
    }

    for (const slot of this.bushSlots) {
      slot.z += forwardStep;
      if (slot.z > 28) slot.z -= 140;
    }

    for (const slot of this.postSlots) {
      slot.z += forwardStep;
      if (slot.z > 28) slot.z -= 138;
    }

    for (const slot of this.rockSlots) {
      slot.z += forwardStep;
      if (slot.z > 28) slot.z -= 140;
    }

    for (const slot of this.cloudSlots) {
      slot.z += forwardStep * 0.35;
      if (slot.z > 32) slot.z -= 148;
      slot.group.position.set(slot.sideOffset, slot.group.position.y, slot.z);
    }

    this.updateTerrainAndRoadVertices();
    this.syncPropHeights();

    // Animate wildlife flying/swimming alongside and above the road
    const t = this.elapsedSec;
    const aheadRoadX = roadCenterX(-this.travelZ - 26);
    for (const actor of this.wildlifeActors) {
      const a = t * actor.speed + actor.phase;
      actor.group.position.x = aheadRoadX + actor.sideOffset + Math.sin(a * 0.65) * actor.orbitR;
      actor.group.position.y = actor.baseY + Math.sin(a * 1.4) * 0.85;
      actor.group.position.z = actor.baseZ + Math.cos(a * 0.5) * 5.0;

      const flap = Math.sin(t * 7.5 * actor.speed + actor.phase);
      actor.leftWing.rotation.z = flap * 0.58;
      actor.rightWing.rotation.z = -flap * 0.58;
      if (actor.tail) {
        actor.tail.rotation.y = Math.sin(t * 9.0 * actor.speed + actor.phase) * 0.45;
      }
    }

    // Animate atmospheric particles
    const pAttr = this.particleGeo.attributes.position as THREE.BufferAttribute;
    const pType = this.currentBiome.particles;
    for (let i = 0; i < this.particleCount; i++) {
      let px = this.particlePositions[i * 3];
      let py = this.particlePositions[i * 3 + 1];
      let pz = this.particlePositions[i * 3 + 2];

      pz += forwardStep * 0.9;
      if (pType === 'bubbles') {
        py += dt * (1.8 + (i % 4) * 0.3);
        px += Math.sin(t * 2 + i) * dt * 0.4;
      } else if (pType === 'snow' || pType === 'leaves') {
        py -= dt * (pType === 'snow' ? 1.5 : 1.1);
        px += Math.sin(t * 1.4 + i) * dt * 0.7;
      } else {
        py += Math.sin(t * 1.8 + i) * dt * 0.45;
        px += Math.cos(t * 1.1 + i) * dt * 0.35;
      }

      if (pz > 22) pz -= 120;
      if (py < -1) py = 20;
      if (py > 22) py = 0;

      this.particlePositions[i * 3] = px;
      this.particlePositions[i * 3 + 1] = py;
      this.particlePositions[i * 3 + 2] = pz;
    }
    pAttr.needsUpdate = true;

    // Road-following smooth camera choreography per stage
    const camLocalZ = 14.5;
    const camWorldZ = -this.travelZ + camLocalZ;
    const lookWorldZ = -this.travelZ - 34;

    const roadXAtCam = roadCenterX(camWorldZ);
    const roadYAtCam = roadElevation(camWorldZ, this.liveAmp, this.liveWaterY);
    const roadXAhead = roadCenterX(lookWorldZ);
    const roadYAhead = roadElevation(lookWorldZ, this.liveAmp, this.liveWaterY);

    let targetCamX = roadXAtCam + Math.sin(t * 0.25) * 0.6;
    let targetCamY = roadYAtCam + 3.6;
    let targetCamZ = camLocalZ;
    let lookX = roadXAhead;
    let lookY = roadYAhead + 2.1;
    let lookZ = -34;

    switch (this.currentStage.choreography) {
      case 'low_parallax':
        targetCamX = roadXAtCam + Math.sin(t * 0.3) * 0.9;
        targetCamY = roadYAtCam + 1.85;
        targetCamZ = 15.0;
        lookX = roadXAhead;
        lookY = roadYAhead + 1.5;
        break;
      case 'panorama_orbit':
        targetCamX = roadXAtCam + Math.sin(t * 0.22) * 3.8;
        targetCamY = roadYAtCam + 7.8 + Math.cos(t * 0.2) * 0.8;
        targetCamZ = 17.5;
        lookX = roadXAhead;
        lookY = roadYAhead + 2.4;
        break;
      case 'tranquil_drift':
        targetCamX = roadXAtCam + Math.cos(t * 0.18) * 1.4;
        targetCamY = roadYAtCam + 4.4 + Math.sin(t * 0.22) * 0.4;
        targetCamZ = 13.8;
        lookX = roadXAhead;
        lookY = roadYAhead + 2.8;
        break;
      default:
        break;
    }

    this.camera.position.x = THREE.MathUtils.damp(this.camera.position.x, targetCamX, 3.2, dt);
    this.camera.position.y = THREE.MathUtils.damp(this.camera.position.y, targetCamY, 3.2, dt);
    this.camera.position.z = THREE.MathUtils.damp(this.camera.position.z, targetCamZ, 3.2, dt);

    _lookTarget.set(lookX, lookY, lookZ);
    this.camera.lookAt(_lookTarget);
  }

  private afterDraw(cb: () => void) {
    const gl = this.renderer.getContext() as WebGL2RenderingContext;
    if (!gl || typeof gl.fenceSync !== 'function') {
      this.frameId = window.setTimeout(cb, 80);
      return;
    }
    const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
    gl.flush();
    const poll = () => {
      if (this.disposed) return;
      const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
      if (state === gl.UNSIGNALED) {
        this.frameId = window.setTimeout(poll, 5);
      } else {
        if (sync) gl.deleteSync(sync);
        this.frameId = window.setTimeout(cb, 80);
      }
    };
    this.frameId = window.setTimeout(poll, 5);
  }

  private scheduleNextTick() {
    if (this.disposed) return;
    if (this.isSoftwareGl) {
      this.afterDraw(this.tick);
    } else {
      this.frameId = window.requestAnimationFrame(this.tick);
    }
  }

  private tick = () => {
    if (this.disposed) return;
    const now = performance.now();
    const dt = Math.min(0.05, Math.max(0.001, (now - this.lastNow) / 1000));
    this.lastNow = now;

    this.stepSimulation(dt);
    this.renderer.render(this.scene, this.camera);
    this.scheduleNextTick();
  };

  public dispose() {
    this.disposed = true;
    window.cancelAnimationFrame(this.frameId);
    window.clearTimeout(this.frameId);
    this.resizeObserver.disconnect();
    this.renderer.domElement.removeEventListener('webglcontextlost', this.handleContextLost);
    this.renderer.domElement.removeEventListener('webglcontextrestored', this.handleContextRestored);

    this.scene.traverse((obj) => {
      if (obj instanceof THREE.Mesh || obj instanceof THREE.Points) {
        obj.geometry.dispose();
        if (Array.isArray(obj.material)) {
          obj.material.forEach((m) => m.dispose());
        } else {
          obj.material.dispose();
        }
      }
    });
    this.particleTexture.dispose();
    this.roadTexture.dispose();
    if (this.scene.environment) {
      this.scene.environment.dispose();
    }
    this.renderer.dispose();
    if (this.renderer.domElement.parentNode === this.container) {
      this.container.removeChild(this.renderer.domElement);
    }
  }
}
